export class updateUserDto{
    name?:string;
    password?:string;
}


