import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from './user.entity';
import { Repository } from 'typeorm';
import { createUserDto } from './dto/create-user.dto'
import { updateUserDto } from './dto/update-user.dto';
import { createProfileDto } from './dto/create-profile.dto';
import { Profile } from './profile.entity';

@Injectable()
export class UsersService {
    
    constructor(
        @InjectRepository(User) private userRepository: Repository<User>,
        @InjectRepository(Profile) private profileRepository: Repository<Profile>
) {

    }

    async createUser(user: createUserDto){

        const userFound = await this.userRepository.findOne({
            where: {
                email: user.email
            }
        })

        if(userFound){
            return new HttpException('User already exists', HttpStatus.CONFLICT)
        }


        const newUser = this.userRepository.create(user)
        return this.userRepository.save(newUser)
    }

   async getUsers(page: number){
        const take = 15;
        const skip = (page - 1) * take;

        const [users,total] = await this.userRepository.findAndCount({
            skip: skip,
            take: take,
            order: { createdAt: 'DESC' }
        })

        return {
            users,
            total,
            page,
            pageCount: Math.ceil(total / take),
        }
    }

    getUser(id: number){
        const userFound = this.userRepository.findOne({
            where: {
                id: id
            }
        })

        if(!userFound){
            return new HttpException('User already no exists', HttpStatus.CONFLICT)
        }
        return userFound
    }

    async deleteUser(id: number){
       const result = await this.userRepository.delete(id);
       if(result.affected === 0){
        throw new HttpException('User not found', HttpStatus.NOT_FOUND)
       }

       return this.userRepository.delete(id);
    }


    updateUser(id: number, user: updateUserDto){

        const userFound = this.userRepository.findOne({
            where: {
                id
            }
        })

        if(!userFound){
            return new HttpException('User not found', HttpStatus.NOT_FOUND)
        }

        return this.userRepository.update(id, user)
    }
    

    
}
