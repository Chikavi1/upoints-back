export class CreateVisitDto {}
