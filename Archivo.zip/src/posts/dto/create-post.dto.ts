export class CreatePostDto {
    title: string
    content: string
    author_id: number
}